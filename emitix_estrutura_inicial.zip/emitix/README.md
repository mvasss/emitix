# Emitix

Plataforma simples, automatizada e acessível para emissão de NFS-e voltada para PMEs.

## Estrutura Inicial

- `frontend/`: Aplicação React com foco em usabilidade.
- `backend/`: API com FastAPI conectada a banco de dados.
